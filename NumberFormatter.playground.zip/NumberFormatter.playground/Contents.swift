// An exercise file for iOS Development Tips Weekly
// A weekly course on LinkedIn Learning for iOS developers
//  Season 16 (Q4 2021) video 09
//  by Steven Lipton (C)2020, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
//This Week:  Number and list formatters
//  For more code, go to http://bit.ly/AppPieGithub

import UIKit

// Basic Number Formatting
let radius = 5
let radiusSq = radius * radius
var area = Double.pi * Double(radiusSq)
var volume = area * 100.0
"radius is " + radius.formatted() + ", area is " + area.formatted() + ", and volume is " + volume.formatted()
"radius is " + radius.formatted(.percent) + ", area is " + (area/100.0).formatted(.percent) + ", and volume is " + volume.formatted(.percent)

//Locales
let loc = "ur_in" // try en_US, fr_FR, ar,ur_in
"radius is " + radius.formatted(.number.locale(Locale(identifier: loc))) + ", area is " + area.formatted(.number.locale(Locale(identifier: loc))) + ", and volume is " + volume.formatted(.number.locale(Locale(identifier: loc)))

//Currency
let cur = "EUR" // try USD,EUR,INR,JPY,ISK(Iceland Krona)
"radius is " + radius.formatted(.currency(code:cur)) + ", area is " + area.formatted(.currency(code:cur)) + ", and volume is " + volume.formatted(.currency(code:cur))


// List formatters
let words = ["Mozzarella","Basil","Tomatoes"]
let numbers = [12.30, 0.090, 112.116]
words.formatted(.list(type: .and))
words.formatted(.list(type: .or))
numbers.formatted(.list(memberStyle:.currency(code:cur), type: .and))
